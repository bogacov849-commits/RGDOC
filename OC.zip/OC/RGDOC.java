import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.URI;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RGDOC extends JFrame {
    private static final String VERSION = "1.0.0";

    // Укажите владельца и репозиторий GitHub, например "myname" и "RGDOC".
    private static final String GITHUB_OWNER = "YOUR_GITHUB_NAME";
    private static final String GITHUB_REPO = "YOUR_REPOSITORY";

    private static final String ADMIN_CODE = "wzxx99yt";
    private static final Path DATA_DIR =
            Paths.get(System.getProperty("user.home"), ".rgdoc");
    private static final Path SHORTCUTS_FILE = DATA_DIR.resolve("shortcuts.txt");
    private static final Path SETTINGS_FILE = DATA_DIR.resolve("settings.txt");

    private final JPanel desktop = new JPanel(null);
    private final JLabel clock = new JLabel();
    private final List<Path> shortcuts = new ArrayList<>();

    private Color backgroundColor = new Color(40, 115, 175);
    private boolean adminMode = false;
    private int cascade = 0;

    public RGDOC() {
        super("RGDOC");
        loadSettings();
        loadShortcuts();

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1150, 760);
        setMinimumSize(new Dimension(850, 580));
        setLocationRelativeTo(null);

        desktop.setOpaque(false);
        setContentPane(new BackgroundPanel());
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(createTopBar(), BorderLayout.NORTH);
        getContentPane().add(desktop, BorderLayout.CENTER);
        getContentPane().add(createDock(), BorderLayout.SOUTH);

        refreshDesktopIcons();
        updateClock();

        // Указан javax.swing.Timer, чтобы избежать конфликта с java.util.Timer.
        new javax.swing.Timer(1000, e -> updateClock()).start();

        SwingUtilities.invokeLater(this::openFilesWindow);
    }

    private JPanel createTopBar() {
        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(new Color(250, 250, 252, 235));
        bar.setBorder(new EmptyBorder(7, 14, 7, 14));

        JLabel brand = new JLabel("●   RGDOC");
        brand.setFont(new Font("SansSerif", Font.BOLD, 14));
        bar.add(brand, BorderLayout.WEST);

        clock.setFont(new Font("SansSerif", Font.PLAIN, 13));
        bar.add(clock, BorderLayout.EAST);
        return bar;
    }

    private void updateClock() {
        clock.setText(LocalDateTime.now().format(
                DateTimeFormatter.ofPattern("EEE, d MMM   HH:mm")));
    }

    private JPanel createDock() {
        JPanel wrap = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 10));
        wrap.setOpaque(false);

        JPanel dock = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 6));
        dock.setBackground(new Color(245, 245, 250, 230));
        dock.setBorder(new EmptyBorder(2, 8, 2, 8));

        addDockButton(dock, "📁", "Файлы", this::openFilesWindow);
        addDockButton(dock, "＋", "Добавить EXE", this::addExeShortcut);
        addDockButton(dock, "⚙", "Настройки", this::openSettings);
        addDockButton(dock, ">_", "Терминал", this::openTerminal);
        addDockButton(dock, "↻", "Проверить обновления", this::checkUpdate);

        wrap.add(dock);
        return wrap;
    }

    private void addDockButton(
            JPanel dock, String icon, String tooltip, Runnable action) {
        JButton button = new JButton(icon);
        button.setToolTipText(tooltip);
        button.setFont(new Font("SansSerif", Font.PLAIN, 24));
        button.setPreferredSize(new Dimension(52, 48));
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setContentAreaFilled(false);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.addActionListener(e -> action.run());
        dock.add(button);
    }

    private void openFilesWindow() {
        JInternalFrame frame = makeWindow("Файлы", 570, 360);
        JPanel panel = new JPanel(new GridLayout(2, 2, 12, 12));
        panel.setBackground(Color.WHITE);

        addActionButton(panel, "＋  Добавить EXE на рабочий стол",
                this::addExeShortcut);
        addActionButton(panel, "⚙  Настройки", this::openSettings);
        addActionButton(panel, ">_  Терминал", this::openTerminal);
        addActionButton(panel, "↻  Проверить обновления", this::checkUpdate);

        frame.setContentPane(wrapContent("Файлы", panel));
        showWindow(frame);
    }

    private JInternalFrame makeWindow(String title, int width, int height) {
        JInternalFrame frame = new JInternalFrame(title, true, true, true, true);
        frame.setDefaultCloseOperation(JInternalFrame.DISPOSE_ON_CLOSE);
        frame.setSize(width, height);

        cascade = (cascade + 1) % 8;
        frame.setLocation(65 + cascade * 27, 45 + cascade * 23);
        return frame;
    }

    private JPanel wrapContent(String title, Component body) {
        JPanel panel = new JPanel(new BorderLayout(10, 12));
        panel.setBackground(Color.WHITE);
        panel.setBorder(new EmptyBorder(16, 16, 16, 16));

        JLabel heading = new JLabel(title);
        heading.setFont(new Font("SansSerif", Font.BOLD, 20));
        panel.add(heading, BorderLayout.NORTH);
        panel.add(body, BorderLayout.CENTER);
        return panel;
    }

    private void showWindow(JInternalFrame frame) {
        desktop.add(frame);
        frame.setVisible(true);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException ignored) {
        }
        desktop.revalidate();
        desktop.repaint();
    }

    private void addActionButton(
            JPanel panel, String text, Runnable action) {
        JButton button = new JButton(text);
        button.setFont(new Font("SansSerif", Font.PLAIN, 14));
        button.setFocusPainted(false);
        button.addActionListener(e -> action.run());
        panel.add(button);
    }

    // Добавляет путь к EXE на рабочий стол RGDOC, не копирует сам файл.
    private void addExeShortcut() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Выберите EXE-файл");
        chooser.setFileFilter(
                new javax.swing.filechooser.FileNameExtensionFilter(
                        "Windows-программы (*.exe)", "exe"));

        if (chooser.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }

        Path selected = chooser.getSelectedFile()
                .toPath().toAbsolutePath().normalize();

        if (!Files.isRegularFile(selected)) {
            showError("Файл не найден.");
            return;
        }

        if (!shortcuts.contains(selected)) {
            shortcuts.add(selected);
            saveShortcuts();
            refreshDesktopIcons();
        }
    }

    private void refreshDesktopIcons() {
        desktop.removeAll();

        int index = 0;
        for (Path path : shortcuts) {
            if (!Files.exists(path)) {
                continue;
            }

            final Path exe = path;
            JButton icon = new JButton("<html><center>🎮<br>"
                    + escapeHtml(fileName(exe)) + "</center></html>");
            icon.setToolTipText(exe.toString());
            icon.setPreferredSize(new Dimension(105, 82));
            icon.setFocusPainted(false);
            icon.setBorderPainted(false);
            icon.setContentAreaFilled(false);
            icon.setForeground(Color.WHITE);
            icon.setFont(new Font("SansSerif", Font.PLAIN, 13));
            icon.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

            int col = index / 6;
            int row = index % 6;
            icon.setBounds(18 + col * 115, 18 + row * 92, 105, 82);

            icon.addActionListener(e -> launchExe(exe));
            icon.addMouseListener(new MouseAdapter() {
                @Override
                public void mousePressed(MouseEvent e) {
                    if (SwingUtilities.isRightMouseButton(e)) {
                        JPopupMenu menu = new JPopupMenu();

                        JMenuItem launch = new JMenuItem("Открыть");
                        launch.addActionListener(a -> launchExe(exe));

                        JMenuItem remove =
                                new JMenuItem("Убрать с рабочего стола");
                        remove.addActionListener(a -> removeShortcut(exe));

                        menu.add(launch);
                        menu.add(remove);
                        menu.show(icon, e.getX(), e.getY());
                    }
                }
            });

            desktop.add(icon);
            index++;
        }

        desktop.revalidate();
        desktop.repaint();
    }

    private void removeShortcut(Path path) {
        shortcuts.remove(path);
        saveShortcuts();
        refreshDesktopIcons();
    }

    private void launchExe(Path exe) {
        try {
            if (!Files.exists(exe)) {
                showError("Файл не найден:\n" + exe);
                return;
            }

            new ProcessBuilder(exe.toString())
                    .directory(exe.getParent().toFile())
                    .start();
        } catch (Exception ex) {
            showError("Не удалось запустить EXE:\n" + ex.getMessage());
        }
    }

    private void openSettings() {
        JInternalFrame frame = makeWindow("Настройки", 480, 300);

        JPanel panel = new JPanel();
        panel.setBackground(Color.WHITE);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JButton colorButton =
                new JButton("Изменить цвет рабочего стола…");
        colorButton.addActionListener(e -> {
            Color chosen = JColorChooser.showDialog(
                    frame, "Цвет рабочего стола", backgroundColor);
            if (chosen != null) {
                backgroundColor = chosen;
                saveSettings();
                repaint();
            }
        });

        JButton resetButton =
                new JButton("Вернуть цвет по умолчанию");
        resetButton.addActionListener(e -> {
            backgroundColor = new Color(40, 115, 175);
            saveSettings();
            repaint();
        });

        JCheckBox clockBox = new JCheckBox("Показывать часы", true);
        clockBox.setBackground(Color.WHITE);
        clockBox.addActionListener(e ->
                clock.setVisible(clockBox.isSelected()));

        panel.add(colorButton);
        panel.add(Box.createVerticalStrut(12));
        panel.add(resetButton);
        panel.add(Box.createVerticalStrut(12));
        panel.add(clockBox);

        frame.setContentPane(wrapContent("Настройки", panel));
        showWindow(frame);
    }

    private void openTerminal() {
        JInternalFrame frame = makeWindow("Терминал", 650, 420);

        JTextArea output = new JTextArea();
        output.setEditable(false);
        output.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));
        output.setText("RGDOC Terminal\nВведите help для списка команд.\n");

        JTextField input = new JTextField();
        input.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));

        Runnable runCommand = () -> {
            String command = input.getText().trim();
            input.setText("");
            if (!command.isEmpty()) {
                executeCommand(command, output);
            }
        };
        input.addActionListener(e -> runCommand.run());

        JPanel body = new JPanel(new BorderLayout(6, 6));
        body.add(new JScrollPane(output), BorderLayout.CENTER);
        body.add(input, BorderLayout.SOUTH);

        frame.setContentPane(wrapContent("Терминал", body));
        showWindow(frame);
        input.requestFocusInWindow();
    }

    private void executeCommand(String command, JTextArea output) {
        output.append("> " + command + "\n");

        if (command.equalsIgnoreCase("help")) {
            output.append("Команды: help, clear, date, apps, obnova\n");
        } else if (command.equalsIgnoreCase("clear")) {
            output.setText("");
        } else if (command.equalsIgnoreCase("date")) {
            output.append(LocalDateTime.now() + "\n");
        } else if (command.equalsIgnoreCase("apps")) {
            if (shortcuts.isEmpty()) {
                output.append("Ярлыков пока нет.\n");
            } else {
                for (Path path : shortcuts) {
                    output.append(fileName(path) + "\n");
                }
            }
        } else if (command.equals(ADMIN_CODE)) {
            adminMode = true;
            output.append("Административный режим включён.\n");
        } else if (command.equalsIgnoreCase("obnova")) {
            if (!adminMode) {
                output.append("Команда недоступна.\n");
            } else {
                adminMode = false;
                output.append("Уведомление отправлено пользователям RGDOC.\n");
                showUpdateNotice();
            }
        } else {
            output.append("Неизвестная команда.\n");
        }

        output.setCaretPosition(output.getDocument().getLength());
    }

    private void showUpdateNotice() {
        // Уведомление показывается в этом экземпляре приложения.
        for (Window window : Window.getWindows()) {
            if (window instanceof RGDOC && window.isShowing()) {
                JOptionPane.showMessageDialog(
                        window,
                        "Обновите OC на GitHub.",
                        "Доступно обновление",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }

    private void checkUpdate() {
        if ("YOUR_GITHUB_NAME".equals(GITHUB_OWNER)
                || "YOUR_REPOSITORY".equals(GITHUB_REPO)) {
            JOptionPane.showMessageDialog(
                    this,
                    "Сначала укажите GITHUB_OWNER и GITHUB_REPO в коде.",
                    "GitHub не настроен",
                    JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        new SwingWorker<String, Void>() {
            @Override
            protected String doInBackground() throws Exception {
                String url = "https://api.github.com/repos/"
                        + GITHUB_OWNER + "/" + GITHUB_REPO
                        + "/releases/latest";

                HttpClient client = HttpClient.newBuilder()
                        .connectTimeout(Duration.ofSeconds(10))
                        .build();

                HttpRequest request = HttpRequest.newBuilder(URI.create(url))
                        .timeout(Duration.ofSeconds(15))
                        .header("Accept", "application/vnd.github+json")
                        .header("User-Agent", "RGDOC")
                        .GET()
                        .build();

                HttpResponse<String> response = client.send(
                        request, HttpResponse.BodyHandlers.ofString());

                if (response.statusCode() != 200) {
                    throw new IOException("GitHub ответил: HTTP "
                            + response.statusCode());
                }

                String json = response.body();
                String tag = jsonString(json, "tag_name");
                String page = jsonString(json, "html_url");
                return tag + "\n" + page;
            }

            @Override
            protected void done() {
                try {
                    String[] result = get().split("\n", 2);
                    String latest = result[0];
                    String page = result.length > 1 ? result[1] : "";

                    if (latest.equalsIgnoreCase("v" + VERSION)
                            || latest.equalsIgnoreCase(VERSION)) {
                        JOptionPane.showMessageDialog(
                                RGDOC.this,
                                "Установлена последняя версия: " + VERSION,
                                "Обновления",
                                JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        int choice = JOptionPane.showConfirmDialog(
                                RGDOC.this,
                                "Доступна версия " + latest
                                        + ". Открыть страницу релиза?",
                                "Доступно обновление",
                                JOptionPane.YES_NO_OPTION);

                        if (choice == JOptionPane.YES_OPTION
                                && !page.isBlank()) {
                            Desktop.getDesktop().browse(URI.create(page));
                        }
                    }
                } catch (Exception ex) {
                    showError("Не удалось проверить обновления:\n"
                            + ex.getMessage());
                }
            }
        }.execute();
    }

    private static String jsonString(String json, String key)
            throws IOException {
        Pattern pattern = Pattern.compile(
                "\"" + Pattern.quote(key)
                        + "\"\\s*:\\s*\"((?:\\\\.|[^\"\\\\])*)\"");
        Matcher matcher = pattern.matcher(json);

        if (!matcher.find()) {
            throw new IOException("В ответе GitHub нет " + key);
        }

        return matcher.group(1)
                .replace("\\/", "/")
                .replace("\\\"", "\"");
    }

    private void loadShortcuts() {
        try {
            Files.createDirectories(DATA_DIR);
            if (!Files.exists(SHORTCUTS_FILE)) {
                return;
            }

            for (String line : Files.readAllLines(
                    SHORTCUTS_FILE, StandardCharsets.UTF_8)) {
                if (!line.isBlank()) {
                    shortcuts.add(Paths.get(line));
                }
            }
        } catch (Exception ex) {
            System.err.println(
                    "Не удалось загрузить ярлыки: " + ex.getMessage());
        }
    }

    private void saveShortcuts() {
        try {
            Files.createDirectories(DATA_DIR);

            List<String> lines = new ArrayList<>();
            for (Path path : shortcuts) {
                lines.add(path.toString());
            }

            Files.write(SHORTCUTS_FILE, lines, StandardCharsets.UTF_8);
        } catch (Exception ex) {
            showError("Не удалось сохранить ярлыки:\n" + ex.getMessage());
        }
    }

    private void loadSettings() {
        try {
            Files.createDirectories(DATA_DIR);
            if (!Files.exists(SETTINGS_FILE)) {
                return;
            }

            Properties properties = new Properties();
            try (Reader reader = Files.newBufferedReader(
                    SETTINGS_FILE, StandardCharsets.UTF_8)) {
                properties.load(reader);
            }

            String color = properties.getProperty("background");
            if (color != null) {
                backgroundColor = Color.decode(color);
            }
        } catch (Exception ex) {
            System.err.println(
                    "Не удалось загрузить настройки: " + ex.getMessage());
        }
    }

    private void saveSettings() {
        try {
            Files.createDirectories(DATA_DIR);

            Properties properties = new Properties();
            properties.setProperty(
                    "background",
                    String.format("#%06X",
                            backgroundColor.getRGB() & 0xFFFFFF));

            try (Writer writer = Files.newBufferedWriter(
                    SETTINGS_FILE, StandardCharsets.UTF_8)) {
                properties.store(writer, "RGDOC settings");
            }
        } catch (Exception ex) {
            showError("Не удалось сохранить настройки:\n" + ex.getMessage());
        }
    }

    private static String fileName(Path path) {
        Path name = path.getFileName();
        return name == null ? path.toString() : name.toString();
    }

    private static String escapeHtml(String text) {
        return text.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;");
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(
                this, message, "RGDOC", JOptionPane.ERROR_MESSAGE);
    }

    private class BackgroundPanel extends JPanel {
        BackgroundPanel() {
            setOpaque(true);
        }

        @Override
        protected void paintComponent(Graphics graphics) {
            super.paintComponent(graphics);

            Graphics2D g = (Graphics2D) graphics.create();
            int w = getWidth();
            int h = getHeight();

            g.setPaint(new GradientPaint(
                    0, 0, backgroundColor,
                    w, h, backgroundColor.darker()));
            g.fillRect(0, 0, w, h);

            g.setColor(new Color(255, 255, 255, 24));
            g.fillOval(w - 420, 70, 480, 480);
            g.fillOval(-140, h - 320, 400, 400);
            g.dispose();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new RGDOC().setVisible(true));
    }
}