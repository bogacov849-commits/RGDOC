@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

where java >nul 2>nul
if errorlevel 1 (
    echo Ошибка: Java не найдена. Установите JDK 11 или новее.
    pause
    exit /b 1
)

where javac >nul 2>nul
if errorlevel 1 (
    echo Ошибка: javac не найден. Установите JDK 11 или новее.
    pause
    exit /b 1
)

echo Компиляция RGDOC...
javac -encoding UTF-8 RGDOC.java
if errorlevel 1 (
    echo.
    echo Ошибка компиляции. Проверьте сообщения выше.
    pause
    exit /b 1
)

echo Запуск RGDOC...
java RGDOC

if errorlevel 1 (
    echo.
    echo Программа завершилась с ошибкой.
    pause
)

endlocal